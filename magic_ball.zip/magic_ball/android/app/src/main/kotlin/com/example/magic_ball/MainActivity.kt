package com.example.magic_ball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
